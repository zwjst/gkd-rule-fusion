import { defineGkdApp } from '@gkd-kit/define';

export default defineGkdApp({
  id: 'com.gentle.ppcat',
  name: '皮皮喵',
  groups: [
    {
      key: 0,
      name: '开屏广告',
      rules: [
        {
          key: 0,
          activityIds: [
            'com.qq.e.ads.PortraitADActivity',
            'com.qq.e.ads.LandscapeADActivity',
          ],
          matches: '@FrameLayout - LinearLayout [text$="惊喜奖励"]',
          snapshotUrls: [
            'https://i.gkd.li/import/12777048',
            'https://i.gkd.li/import/12858015',
          ],
        },
        {
          key: 1,
          activityIds: 'com.qq.e.ads.PortraitADActivity',
          matches: '[text="放弃奖励离开"]',
          snapshotUrls: 'https://i.gkd.li/import/12777058',
        },
        {
          key: 2,
          activityIds: 'com.qq.e.ads.PortraitADActivity',
          matches: '@ImageView - WebView > [text="优量汇-插屏视频endcard"]',
          snapshotUrls: 'https://i.gkd.li/import/12777051',
        },
        {
          key: 3,
          activityIds: [
            'com.qq.e.ads.PortraitADActivity',
            'com.gentle.ppcat.MainActivity',
            'com.hihonor.android.launcher.drawer.DrawerLauncher',
          ],
          matches: '[desc="关闭喵"]',
          snapshotUrls: [
            'https://i.gkd.li/import/12777059',
            'https://i.gkd.li/import/12777054', // activityId: 'com.gentle.ppcat.MainActivity'
            'https://i.gkd.li/import/13797494', // activityId: 'com.hihonor.android.launcher.drawer.DrawerLauncher'
          ],
        },
      ],
    },
  ],
});

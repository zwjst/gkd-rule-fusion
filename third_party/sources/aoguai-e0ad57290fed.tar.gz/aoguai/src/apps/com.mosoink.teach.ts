import { defineGkdApp } from '@gkd-kit/define';

export default defineGkdApp({
  id: 'com.mosoink.teach',
  name: '云班课',
  groups: [
    {
      key: 0,
      name: '全屏广告-班课列表弹窗广告',
      desc: '关闭班课列表页面的全屏弹窗广告',
      enable: false,
      activityIds: [
        'com.mosoink.teach.MainMenuActivity',
        'com.bytedance.sdk.openadsdk.stub.activity.Stub_Standard_Portrait_Activity',
      ],
      rules: [
        {
          key: 2,
          matches: '@Image[text.length=0] < View <n * > [text="反馈"]',
          snapshotUrls: 'https://i.gkd.li/i/15051392',
        },
      ],
    },
  ],
});
